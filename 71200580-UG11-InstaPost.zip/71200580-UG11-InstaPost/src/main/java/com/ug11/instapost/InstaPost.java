package com.ug11.instapost;

public class InstaPost {
    private int totalMention;
    private String email;
    private String username;


    public String toString() {
        return "InstaPost{" +
                "totalMention=" + totalMention +
                ", email='" + email + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
