package com.ug11.kalkulasirupiah;

public class AppKalkulasiRupiah {
        public static void main(String[] args) {
            String text;
            int rincian;
            int total;

            System.out.println("--------------------");
            System.out.println("Ibu membeli minyak goreng seharga Rp22.500,00 dan margarin seharga Rp12.500,00 di\n" +
                            "supermarket");
            System.out.println("rincian biaya : Rp22.500,00 + Rp12.500,00");
            System.out.println("Total : 3500");
        }
        
}
